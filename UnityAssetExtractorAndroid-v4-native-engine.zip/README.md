# Unity Asset Extractor Android — native engine build

This version replaces the Chaquopy/UnityPy architecture with the Android-native AssetStudioMobile engine.

Why: UnityPy currently pulls native Python dependencies such as `texture2ddecoder` and `fsb5` which do not have the required Chaquopy Android arm64 wheels. The build therefore cannot resolve its Python requirements.

The native engine used here is Kotlin + NDK/JNI and already supports Unity serialized files, AssetBundles, `.assets`, `.unity3d`, external `.resS`, texture decoding and batch export. It also has memory-safety/batch-loading protections for large game folders.

The GitHub Actions workflow fetches the upstream engine at build time, applies the app identity patch, and produces a release APK.

## Build

1. Upload this project to GitHub.
2. Open **Actions → Build Unity Asset Extractor → Run workflow**.
3. Download `UnityAssetExtractor-release-apk` from the completed workflow.

## Current scope

This is the native-engine replacement needed to get past the UnityPy/Chaquopy blocker. The upstream engine provides folder loading and batch export, including Texture2D/Sprite PNG export and VideoClip/raw export. The custom one-tap Images/Videos/Both extractor controls can be layered on top of this engine next without bringing Python back into the APK.

Upstream engine: https://github.com/zuimo888/AssetStudioMobile
