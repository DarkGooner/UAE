from pathlib import Path
import sys

root = Path(sys.argv[1])

gradle = root / "app/build.gradle.kts"
s = gradle.read_text()
s = s.replace('applicationId = "com.assetstudio.mobile"', 'applicationId = "com.darkgooner.unityextractor"')
s = s.replace('versionCode = 38', 'versionCode = 1')
s = s.replace('versionName = "1.10.2"', 'versionName = "1.0.0"')
gradle.write_text(s)

strings = root / "app/src/main/res/values/strings.xml"
s = strings.read_text()
s = s.replace('<string name="app_name">AssetStudio</string>', '<string name="app_name">Unity Asset Extractor</string>')
strings.write_text(s)

# Keep the project reproducible on GitHub runners even if the upstream mirror is unavailable.
wrapper = root / "gradle/wrapper/gradle-wrapper.properties"
s = wrapper.read_text()
s = s.replace('https://mirrors.cloud.tencent.com/gradle/gradle-8.7-bin.zip', 'https://services.gradle.org/distributions/gradle-8.7-bin.zip')
wrapper.write_text(s)
