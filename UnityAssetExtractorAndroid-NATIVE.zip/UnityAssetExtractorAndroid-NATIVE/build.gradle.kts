plugins {
    // The actual plugin versions are provided by AssetStudioMobile's checked-in
    // Gradle project when the native build workflow overlays its source.
}
