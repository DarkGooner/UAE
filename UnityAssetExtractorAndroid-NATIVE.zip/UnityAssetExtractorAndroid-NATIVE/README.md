# Unity Asset Extractor Android — Native Engine

This project deliberately does NOT use Chaquopy, Python, or UnityPy.

The GitHub Actions workflow pulls the open-source AssetStudioMobile Android project
at build time and builds its Kotlin + NDK/JNI Unity asset engine.

Why this architecture:
- UnityPy on Android/Chaquopy is blocked by native Python dependencies such as
  texture2ddecoder and fsb5 for the target arm64/Python environment.
- AssetStudioMobile already contains a Kotlin port of the Unity/AssetStudio parser
  and an NDK/JNI texture decoder.

IMPORTANT:
This ZIP is the native-engine bootstrap/baseline. It is intentionally separated
from the custom "one-tap extractor" UI. First verify that the native engine builds
and the APK installs/opens on the phone. After that, the extractor-specific UI and
direct folder-to-folder export can be layered on top of this known-good engine.

The build uses:
https://github.com/zuimo888/AssetStudioMobile
