The real Android app module is supplied by the pinned AssetStudioMobile
source during the GitHub Actions build.

This placeholder exists so the ZIP visibly contains an `app/` directory.
The workflow replaces it with the upstream native Android app before Gradle runs.
