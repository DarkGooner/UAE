# Native engine status

## Architecture

Android Kotlin/Jetpack Compose
        |
        +-- AssetStudioMobile Kotlin Unity parser
        |
        +-- JNI
        |
        +-- C++ NDK texture decoder

There is NO:
- Chaquopy
- Python
- UnityPy
- texture2ddecoder Python wheel
- fsb5 Python wheel

## Upstream capabilities

The selected upstream project documents support for:
- .assets
- .bundle
- .unity3d
- AssetBundles
- .resS external data
- Texture2D/Sprite export
- many compressed Unity texture formats
- recursive folder loading
- memory/OOM protections
- native NDK/JNI texture decoding

The next engineering stage is to replace its general-purpose browser/export UI
with the dedicated extractor workflow:
1. Select game folder
2. Select destination
3. Images / Videos / Both
4. Skip existing
5. Preserve folder structure
6. Workers 1–4
7. Pause / Resume / Stop
8. Progress, speed, counts
9. Direct export without creating a ZIP
